﻿
using var game = new Snake.Game1();
game.Run();
